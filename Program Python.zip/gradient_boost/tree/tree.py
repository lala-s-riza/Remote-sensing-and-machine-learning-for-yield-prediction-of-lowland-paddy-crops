import numpy as np

from gradient_boost.utils import divide_by_threshold
from gradient_boost.utils import variance

# superclass untuk regression tree
class Tree(object):
    def __init__(self, min_samples_split = 2, max_depth = 4):
        self.root = None # inisialisasi root pada tree
        self.min_samples_split = min_samples_split
        self.max_depth = max_depth

        self._impurity = None
        self._leaf_value = None

    # fungsi training regression tree
    def fit(self, X, y):
        self.root = self._tree_building(X, y)

    # fungsi untuk membangun tree
    def _tree_building(self, X, y, tree_depth = 0):

        # inisialisasi impurity dan split data terbaik
        best_impurity = 0
        best_splits = None

        # jumlah sampel dan jumlah fitur (kolom)
        n_samples = np.shape(X)[0]
        n_features = np.shape(X)[1]

        if len(np.shape(y)) == 1:
            y = np.expand_dims(y, axis=1)


        Xy = np.concatenate((X, y), axis=1)

        if self.max_depth >= tree_depth and self.min_samples_split <= n_samples:
            for feature_index in range(n_features):
                # looping fitur yang tersedia

                feature_values = np.expand_dims(X[:, feature_index], axis = 1)
                unique_values = np.unique(feature_values)

                for threshold in unique_values:
                    # looping nilai fitur yang unik
                    Xy_1, Xy_2 = divide_by_threshold(Xy, feature_index, threshold)

                    if len(Xy_1) > 0 and len(Xy_2) > 0:
                        # Select the y-values of the two sets
                        y1 = Xy_1[:, n_features:]
                        y2 = Xy_2[:, n_features:]

                        # hitung impurity berdasarkan variance reduction
                        impurity = self._impurity(y, y1, y2)

                        if best_impurity < impurity:
                            # mendapatkan impurity dan split data terbaik
                            best_impurity = impurity
                            best_splits = {
                                "feature_index": feature_index,   # indeks fitur terbaik
                                "feature_threshold": threshold,   # threshold fitur terbaik
                                "X_left": Xy_1[:, :n_features],   # X untuk branch kiri
                                "y_left": Xy_1[:, n_features:],   # y untuk branch kiri
                                "X_right": Xy_2[:, :n_features],  # X untuk branch kanan
                                "y_right": Xy_2[:, n_features:]   # y untuk branck kanan
                                }

        if best_impurity > (1e-7):
            # membuat branch kanan dan kiri berdasarkan hasil split data terbaik
            branch_left = self._tree_building(best_splits["X_left"], best_splits["y_left"], tree_depth + 1)
            branch_right = self._tree_building(best_splits["X_right"], best_splits["y_right"], tree_depth + 1)

            # return node
            return Node(feature_index = best_splits["feature_index"], feature_threshold = best_splits["feature_threshold"], branch_left = branch_left, branch_right = branch_right)

        # return nilai leaf
        return Node(value = self._leaf_value(y))

    # fungsi untuk mendapatkan nilai leaf berdasarkan X yang diprediksi
    def _leaf_searching(self, X, tree=None):

        if tree is None:
            tree = self.root

        # return nilai jika sudah sampai pada leaf yang dituju
        if tree.value is not None:
            return tree.value

        feature_value = X[tree.feature_index]

        # cek nilai X yang diprediksi berdasarkan threshold
        branch = tree.branch_right
        if feature_value >= tree.feature_threshold:
                branch = tree.branch_left

        # rekursif apabila leaf belum ditemukan
        return self._leaf_searching(X, branch)

    # fungsi testing regression tree
    def predict(self, X):
        y_pred = []
        for sample in X:
            # melakukan pencarian leaf pada setiap X
            value = self._leaf_searching(sample) 
            y_pred.append(value)

        return y_pred

    def print_tree(self, tree=None, indent=" "):
        if not tree:
            tree = self.root

        if tree.value is not None:
            print (tree.value)
        else:
            # Print test
            print ("%s:%s? " % (tree.feature_index, tree.feature_threshold))
            # Print the true scenario
            print ("%sT->" % (indent), end="")
            self.print_tree(tree.branch_left, indent + indent)
            # Print the false scenario
            print ("%sF->" % (indent), end="")
            self.print_tree(tree.branch_right, indent + indent)

# kelas untuk node yang sudah dibuat
class Node():
    def __init__(self, feature_index = None, feature_threshold = None, value = None, branch_left = None, branch_right = None):
        self.feature_index = feature_index 
        self.feature_threshold = feature_threshold   
        self.value = value 
        self.branch_left = branch_left
        self.branch_right = branch_right 


class RegressionTree(Tree):
    # fungsi training regression tree
    def fit(self, X, y):
        self._impurity = self._variance_reduction
        self._leaf_value = self._y_mean
        super(RegressionTree, self).fit(X, y)

    # menghitung variance reduction untuk sebagai impurity
    def _variance_reduction(self, y, y1, y2):
        variance_total = variance(y)
        
        variance_y1 = variance(y1)
        prob_1 = len(y1) / len(y)
        
        variance_y2 = variance(y2)
        prob_2 = len(y2) / len(y)

        variance_reduction = variance_total - ((prob_1 * variance_y1) + (prob_2 * variance_y2))

        return variance_reduction
    
    # menghitung nilai leaf berdasarkan y pada leaf
    def _y_mean(self, y):
        value = np.mean(y, axis=0)

        if len(value) == 1:
            return value[0]
        
        return value

    

