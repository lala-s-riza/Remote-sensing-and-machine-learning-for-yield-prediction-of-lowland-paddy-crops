# import library
import numpy as np
import progressbar

# import helper
from gradient_boost.loss import SquareLoss
from gradient_boost.tree import RegressionTree
from gradient_boost.utils import bar_widgets

class GradientBoosting(object):
    # superclass untuk gradient boosting regressor

    def __init__(self, estimators, learning_rate, min_samples_split, max_depth):
        self.estimators = estimators
        self.learning_rate = learning_rate
        self.min_samples_split = min_samples_split
        self.max_depth = max_depth
        self.bar = progressbar.ProgressBar(widgets = bar_widgets)
        
        # inisialisasi square loss function
        self.loss = SquareLoss()

        # inisialisasi regression tree sebanyak estimators
        self.trees = []
        for _ in range(estimators):
            tree = RegressionTree(
                    min_samples_split=self.min_samples_split,
                    max_depth=self.max_depth)
            self.trees.append(tree)


    def fit(self, X, y):
        # inisialisasi model dengan nilai konstan
        y_pred = np.full(np.shape(y), np.mean(y, axis=0))
        
        for i in self.bar(range(self.estimators)):
            # hitung pseudo_residual
            pseudo_residual = self.loss.pseudo_residual(y, y_pred)
            
            # training & testing regression tree
            self.trees[i].fit(X, pseudo_residual)
            update = self.trees[i].predict(X)

            # update nilai y prediction
            update = np.multiply(self.learning_rate, update)
            y_pred = y_pred + update


    def predict(self, X):
        # inisialisasi array untuk y prediction
        y_pred = np.array([])

        for tree in self.trees:

            # testing regression tree
            update = tree.predict(X)
            update = np.multiply(self.learning_rate, update)

            # Update nilai y prediction
            if y_pred.any():
                y_pred = y_pred + update
            else:
                y_pred = update

        min_pred = min(y_pred)
        y_pred = y_pred - min_pred

        return y_pred

class GradientBoostingRegressor(GradientBoosting):

    def __init__(self, estimators = 100, learning_rate = 0.1, min_samples_split = 2, max_depth = 4):
        super(GradientBoostingRegressor, self).__init__(
            estimators = estimators, 
            learning_rate = learning_rate, 
            min_samples_split = min_samples_split, 
            max_depth = max_depth)


