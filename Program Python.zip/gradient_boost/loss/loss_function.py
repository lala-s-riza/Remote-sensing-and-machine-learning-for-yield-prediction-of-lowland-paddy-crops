import numpy as np

# superclass untuk square loss function
class LossFunction(object):
    def loss(self, y_true, y_pred):
        return NotImplementedError()

    def gradient(self, y, y_pred):
        raise NotImplementedError()

    def residual(self, y, y_pred):
        raise NotImplementedError()

class SquareLoss(LossFunction):
    def __init__(self): pass

    # square loss function
    def loss(self, y, y_pred):
        return 0.5 * np.power((y - y_pred), 2)

    # turunan square loss function
    def gradient(self, y, y_pred):
        return -(y - y_pred)

    def pseudo_residual(self, y, y_pred):
        return (y - y_pred)

