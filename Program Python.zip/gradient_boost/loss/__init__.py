from .loss_function import SquareLoss
