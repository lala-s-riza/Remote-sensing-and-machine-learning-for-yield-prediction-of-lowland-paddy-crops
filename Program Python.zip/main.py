# import library
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import progressbar

from math import sqrt
from sklearn.preprocessing import StandardScaler 

from gradient_boost import GradientBoostingRegressor
from gradient_boost.utils import train_test_split
from gradient_boost.utils import root_mean_squared_error
from gradient_boost.utils import bar_widgets

def main():

	# input data dari file .csv
	data = input()
	X, y = preprocessing(data)
	

	# parameter untuk model
	params = {'estimators': 200,
		'learning_rate': 0.1,
		'max_depth': 4,
		'min_samples_split': 2}

	check_params(params)

	# membagi data (training 80%, testing 20%)
	X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
	result_test = X_test

	# standardisasi data
	X_train, X_test = standardization(X_train, X_test)
	
	# inisialisasi model
	model = GradientBoostingRegressor(**params)

	# training model
	model.fit(X_train, y_train)

	# testing model
	y_pred = model.predict(X_test)

	# plot
	plot(y_pred, y_test) 

	# simpan hasil prediksi ke file .csv
	save_to_csv(result_test, y_pred)

def input():
	data = pd.read_csv('gradient_boost/data/data.csv')
	return data

def preprocessing(data):

	# cek jumlah fitur untuk X
	if data.shape[1] != 6:
	    raise ValueError("Jumlah fitur harus sebanyak 5, namun "
	    	"fitur yang ada hanya %r." % (data.shape[1]-1))

	# mengambil kolom-kolom fitur X 
	data_x = data[['ndvi', 'populasi', 'periode', 'suhu', 'luas_area_tanam']]

	# one hot encoding pada fitur kategorikal periode
	data['periode'] = pd.Categorical(data['periode'])
	dataDummies = pd.get_dummies(data['periode'], prefix = 'category')
	data_x = pd.concat([data_x, dataDummies], axis = 1)
	del data_x['periode']

	# X
	data_x = data_x.to_numpy()
	X = data_x.reshape((-1, 7))    

	# y
	data_y = np.atleast_2d(data["hasil_panen"].values).T
	y = data_y[:, 0]

	return X, y

def check_params(params):

	estimators = params['estimators']
	learning_rate = params['learning_rate']
	max_depth = params['max_depth']
	min_samples_split = params['min_samples_split']

	# cek parameter
	if estimators <= 0:
		raise ValueError("Jumlah estimator (regression tree) yang "
			"akan dibuat harus lebih besar dari 0.")

	if learning_rate <= 0:
		raise ValueError("Nilai learning rate harus lebih besar dari 0.")

	if max_depth <= 0:
		raise ValueError("Nilai maksimum kedalaman regression tree "
			"harus lebih besar dari 0.")

	if min_samples_split <= 0:
		raise ValueError("Nilai minimum samples split "
			"harus lebih besar dari 0.")

def standardization(X_train, X_test):
	# standardisasi data
	scaler = StandardScaler().fit(X_train)
	X_train = scaler.transform(X_train)
	X_test = scaler.transform(X_test)

	return X_train, X_test

def plot(y_pred, y_test):

	rmse = root_mean_squared_error(y_test, y_pred)

	plt.scatter(y_test,y_pred)
	plt.grid()
	plt.suptitle("RMSE: %.2f" % rmse, fontsize=10)
	plt.xlabel('Hasil Panen (Observasi)')
	plt.ylabel('Hasil Panen (Prediksi)')
	plt.title('Scatter plot hasil panen observasi dan prediksi')
	plt.savefig('Scatter plot.png')
	plt.show()

def save_to_csv(result_test, y_pred):
	X_test = pd.DataFrame(result_test)
	X_test.columns = ['ndvi', 'populasi', 'suhu', 'luas_area_tanam', 
		'category_P1', 'category_P2', 'category_P3']
	y_pred_df = pd.Series(y_pred)
	result = X_test.assign(hasil_panen = y_pred_df)
	result.to_csv("Hasil.csv", index = False)

if __name__ == "__main__":
    main()
